<?php
	require_once('dbconfig/config.php');
?>	
<!DOCTYPE html>
<html>
<head>


    <title> </title>
    <link rel="stylesheet" href="css/font-awesome.min.css" >
    <link rel="stylesheet" href="css/bootstrap.css" >
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/style.css">


</head>

<body>
<div class="container-fluid">
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<div class="navbar-header">
			  <li class="navbar-brand" style="list-style:none">Uttara High School</li>
			</div>
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="teachers.php">Teacher</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> <span style = "font-size:18px"> LogIn<span> </a></li>
			</ul>
		</div>
	</nav>
</div>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
				<div id="myCarousel" class="carousel slide" data-ride="carousel">

					<ol class="carousel-indicators">
					  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					  <li data-target="#myCarousel" data-slide-to="1"></li>
					  <li data-target="#myCarousel" data-slide-to="2"></li>
					</ol>

					<div class="carousel-inner" >
					<?php 
						$query = "SELECT * FROM `slide` ";
						$query_run = mysqli_query($con,$query);
						if($query_run){
							$i = 0;
							while($row = $query_run->fetch_assoc()){
								if($i == 0){
									echo "
										<div class='item active'>
											<img src='upload/slide/".$row['slide']."' class='slide-responsive'>
											<div class='carousel-caption'>
												<h3>".$row['slide_title']."</h3>
											</div>
										</div>
										";
								}
								else{
									echo "
										<div class='item'>
											<img src='upload/slide/".$row['slide']."' class='slide-responsive'>
											<div class='carousel-caption'>
												<h3>".$row['slide_title']."</h3>
											</div>
										</div>
										";
								}
								$i++;
							}
						}
					?>
					</div>

					<a class="left carousel-control" href="#myCarousel" data-slide="prev">
					  <span class="glyphicon glyphicon-chevron-left"></span>
					  <span class="sr-only">Previous</span>
					</a>
					<a class="right carousel-control" href="#myCarousel" data-slide="next">
					  <span class="glyphicon glyphicon-chevron-right"></span>
					  <span class="sr-only">Next</span>
					</a>
				</div>
		</div>
	</div>
</div>

<div class="container">
	<div class="row" style="margin-top:20px">
		<div class="col-md-8">
			<div class="about-us">
			<h3>About Us</h3>
			<p class="text-justify">
				Definition of paragraph. 1 a : a subdivision of a written composition that consists of one or more sentences, deals with one point or gives the words of one speaker, and begins on a new usually indented line. The introductory paragraphs were written by the editor.
				What is a Paragraph? Definition, Examples of Paragraphs - Writing ...
				https://writingexplained.org › The Writer’s Dictionary

				How long is one paragraph? We give the definition of a paragraph, discuss how long they should be, and more. What is a body paragraph?
				Paragraph definition and meaning | Collins English Dictionary
				https://www.collinsdictionary.com/dictionary/english/paragraph

				Paragraph definition: A paragraph is a section of a piece of writing. A paragraph always begins on a new line... | Meaning, pronunciation, translations and ...
			</p>			
			</div>
		</div>
		<div class="col-md-4">
			<div class="notice-board">
				<h3>NOTICE BOARD</h3>
				<div class="list-group">
					<?php 
						$query = "SELECT * FROM `notice` ";
						$query_run = mysqli_query($con,$query);
						if($query_run){
							while($row = $query_run->fetch_assoc()){
								echo "<a href='notice.php?notice=".$row['id']."' class='list-group-item'>".$row['notice_title']."</a>";
							}
						}
					?>
				</div>
			</div>
		</div>
	</div>
</div>	

<div class="footer" style="height:250px;background:#4CAF50;margin-top:30px">
	   <div class="col-sm-12">
      <div class="footer-inner text-center col-sm-4">
              <h4><i>Contact Us</i><hr></h4>
              <p><span class="glyphicon glyphicon-phone"></span> Call 02-48951632, 02-48951633</p><br>
              <p><span class="glyphicon glyphicon-map-marker"></span> ADDRESS : Dhaka, Bangladesh.</p><br>
              <p><span class="glyphicon glyphicon-envelope"></span> EMAIL : email@admin.com</p><br>
     </div>
     <div class="footer-inner text-center col-sm-4">
     	<img src="images/logo.png">
     </div>

     <div class="footer-inner text-center col-sm-4">
      <h4 class="text-uppercase footer_header">our Address</h4><hr>

            <p> Road# 1 & 27</p><br>
            <p> Sector# 7, Uttara</p><br>
            <p> Dhaka, 1230</p><br>
     </div>
    </div>
	<hr>
	<p class="text-center" style="font-size:16px;color:white;padding:10px"> Copyright © <?php echo date("Y"); ?></p>
</div>


	
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>