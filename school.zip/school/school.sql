-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2018 at 06:10 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `s_id` varchar(40) NOT NULL,
  `e_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `s_id`, `e_id`, `status`, `date`, `month`, `year`) VALUES
(1, 'ID2018S001', 1, 1, 13, 9, 2018),
(2, 'ID2018S002', 1, 0, 13, 9, 2018),
(3, 'ID2018S003', 1, 1, 13, 9, 2018),
(4, 'ID2018S005', 1, 1, 13, 9, 2018),
(5, 'ID2018S001', 1, 1, 17, 9, 2018),
(6, 'ID2018S002', 1, 1, 17, 9, 2018),
(7, 'ID2018S003', 1, 1, 17, 9, 2018),
(8, 'ID2018S005', 1, 1, 17, 9, 2018),
(9, 'ID2018S001', 1, 1, 17, 9, 2018),
(10, 'ID2018S002', 1, 1, 17, 9, 2018),
(11, 'ID2018S003', 1, 1, 17, 9, 2018),
(12, 'ID2018S005', 1, 1, 17, 9, 2018),
(13, 'ID2018S001', 1, 1, 17, 9, 2018),
(14, 'ID2018S002', 1, 1, 17, 9, 2018),
(15, 'ID2018S003', 1, 1, 17, 9, 2018),
(16, 'ID2018S005', 1, 1, 17, 9, 2018),
(17, 'ID2018S001', 1, 1, 17, 9, 2018),
(18, 'ID2018S002', 1, 0, 17, 9, 2018),
(19, 'ID2018S003', 1, 1, 17, 9, 2018),
(20, 'ID2018S005', 1, 1, 17, 9, 2018);

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `id` int(11) NOT NULL,
  `batchnumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`id`, `batchnumber`) VALUES
(1, 2018);

-- --------------------------------------------------------

--
-- Table structure for table `enroll`
--

CREATE TABLE `enroll` (
  `e_id` int(11) NOT NULL,
  `t_id` int(11) NOT NULL,
  `sub_name` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `section` varchar(5) NOT NULL,
  `d_group` varchar(20) NOT NULL,
  `batchnumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enroll`
--

INSERT INTO `enroll` (`e_id`, `t_id`, `sub_name`, `class`, `section`, `d_group`, `batchnumber`) VALUES
(1, 1, 'Camistry', 9, 'A', 'Science', 2018),
(2, 4, 'English', 9, 'A', 'Science', 2018),
(3, 5, 'Bangla', 9, 'A', 'Science', 2018);

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `id` int(11) NOT NULL,
  `notice_title` varchar(100) NOT NULL,
  `notice` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `notice_title`, `notice`, `date`) VALUES
(1, 'Exam Notice', 'iAqw7n4.jpg', '2018-09-17 09:39:16'),
(2, 'Enroll Notice ', 'hhhh.jpg', '2018-09-17 09:41:20');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `enroll_id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `term` int(11) NOT NULL,
  `mark` int(11) NOT NULL,
  `grade` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `id` int(11) NOT NULL,
  `slide_title` varchar(100) NOT NULL,
  `slide` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `slide_title`, `slide`) VALUES
(1, 'Uttara High School Main Get', 'uttara-high-school-college-online-dhaka.jpg'),
(2, 'Award Giving Ceremony', 'Most-talented-girl-in-the-country-Sraboni.jpg'),
(3, 'School Main Building', 'Uttara_High_School__College-770x400.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `s_id` varchar(50) NOT NULL,
  `s_name` varchar(50) NOT NULL,
  `s_password` varchar(20) NOT NULL,
  `s_class` varchar(20) NOT NULL,
  `s_group` varchar(20) NOT NULL,
  `s_section` varchar(20) NOT NULL,
  `s_batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `s_id`, `s_name`, `s_password`, `s_class`, `s_group`, `s_section`, `s_batch`) VALUES
(1, 'ID2018S001', 'Atiur Rahman', '123456', '9', 'Science', 'A', 2018),
(2, 'ID2018S002', 'Samirul Islam', '123456', '9', 'Science', 'A', 2018),
(3, 'ID2018S003', 'Abdul Kuddus', '123456', '9', 'Science', 'A', 2018),
(4, 'ID2018S005', 'Habib Ahsan', '123456', '9', 'Science', 'A', 2018);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `sub_code` varchar(50) NOT NULL,
  `sub_class` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `sub_name`, `sub_code`, `sub_class`) VALUES
(1, 'Math', '', 0),
(2, 'Bangla', '', 0),
(3, 'English', '', 0),
(5, 'SOCIAL SCIENCE', '', 0),
(6, 'Camistry', '', 0),
(7, 'Physics', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `t_name` varchar(50) NOT NULL,
  `t_image` text NOT NULL,
  `t_email` varchar(100) NOT NULL,
  `t_phone` varchar(20) NOT NULL,
  `t_id` varchar(50) NOT NULL,
  `t_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `t_name`, `t_image`, `t_email`, `t_phone`, `t_id`, `t_password`) VALUES
(1, 'Md Abdul Kader', 'Md.-Ahsan-Habib-Picture-PP.jpg', 'kadir@mail.com', '01721445566', 'T2018001', '123456'),
(2, 'Samiul Alom', 'Adnan_Hassan.jpg', 'Alom@mail.com', '01966554422', 'T2018002', '123456'),
(3, 'Kadirul Islam', 'images.jpg', 'islam@mail.com', '01533669988', 'T2018003', '123456'),
(4, 'Samina Karim', 'SAD-44670-PP-2-copy.jpg', 'karim@mail.com', '01644556622', 'T2018004', '123456'),
(5, 'Kulsum akhtar', 'pp.jpg', 'kulsum@mail.com', '01566552233', 'T2018005', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enroll`
--
ALTER TABLE `enroll`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `enroll`
--
ALTER TABLE `enroll`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
