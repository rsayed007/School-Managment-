<?php 
	session_start();
	require_once('dbconfig/config.php');
	
?>	
<!DOCTYPE html>
<html>
<head>


    <title> </title>
    <link rel="stylesheet" href="css/font-awesome.min.css" >
    <link rel="stylesheet" href="css/bootstrap.css" >
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/style.css">


</head>

<body>

<div class="container-fluid">
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<div class="navbar-header">
			  <li class="navbar-brand" style="list-style:none">School Web</li>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li class="active"><a href="teachers.php">Teacher</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> <span style = "font-size:18px"> LogIn<span> </a></li>
			</ul>
		</div>
	</nav>
</div>


<div class="container">
	<div class="row">
		<div class="col-md-12" style = "margin-top:20px;">
			<?php 
				$query = "SELECT * FROM teachers";
				$query_run = mysqli_query($con,$query);
				if ($query_run) {	
					if(mysqli_num_rows($query_run)>0){

					   while($row = $query_run->fetch_assoc()){
						echo "
							<div class='teacher-info'>
								<ul>
									<li><img src='upload/".$row['t_image']."'/></li>
									<li><h5>Name: <span>".$row['t_name']."</span></h5></li>
									<li><h5>Email: <span>".$row['t_email']."</span></h5></li>
									<li><h5>Phone: <span>+88".$row['t_phone']."</span></h5></li>
								</ul>
							</div>
						";
					   }
					 }
				}				
			?>
		</div>
	
	</div>
</div>
<div class="footer" style="height:250px;background:#4CAF50;margin-top:30px">
	   <div class="col-sm-12">
      <div class="footer-inner text-center col-sm-4">
              <h4><i>Contact Us</i><hr></h4>
              <p><span class="glyphicon glyphicon-phone"></span> Call 02-48951632, 02-48951633</p><br>
              <p><span class="glyphicon glyphicon-map-marker"></span> ADDRESS : Dhaka, Bangladesh.</p><br>
              <p><span class="glyphicon glyphicon-envelope"></span> EMAIL : email@admin.com</p><br>
     </div>
     <div class="footer-inner text-center col-sm-4">
     	<img src="images/logo.png">
     </div>

     <div class="footer-inner text-center col-sm-4">
      <h4 class="text-uppercase footer_header">our Address</h4><hr>

            <p> Road# 1 & 27</p><br>
            <p> Sector# 7, Uttara</p><br>
            <p> Dhaka, 1230</p><br>
     </div>
    </div>
	<hr>
	<p class="text-center" style="font-size:16px;color:white;padding:10px"> Copyright © <?php echo date("Y"); ?></p>
</div>


	
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>